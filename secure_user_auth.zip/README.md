
# Secure User Authentication System

A full-stack app with secure login/registration using Flask (Python) and plain HTML+JavaScript.

## Features
- User registration with hashed passwords
- Secure login and session management
- Protected route access after authentication
- Logout functionality

## Backend Setup
1. Install requirements:
```
pip install flask flask_sqlalchemy flask_cors
```

2. Run the backend:
```
python app.py
```

## Frontend
Open `frontend.html` in your browser and interact with the backend at `http://127.0.0.1:5000`.

Use responsibly and only for learning purposes!
